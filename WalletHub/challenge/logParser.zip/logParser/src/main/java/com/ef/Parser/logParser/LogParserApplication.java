package com.ef.Parser.logParser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LogParserApplication {

	public static void main(String[] args) {
		SpringApplication.run(LogParserApplication.class, args);
	}
}
